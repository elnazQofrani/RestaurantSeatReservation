﻿namespace BookTableReservation.Enums
{
    public enum BookingStatus
    {
        Confirmed=1,
        Canceled=2
    }
}
